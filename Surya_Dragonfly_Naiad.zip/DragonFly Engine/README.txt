PROJECT 2B - DRAGONFLY NAIAD

-------------------------------------------------------------

Name: Surya Srinivasan

WPI ID: 901004540

-------------------------------------------------------------

PLATFORM: Windows

-------------------------------------------------------------

FILE STRUCTURE:

DragonFly Engine
	|
	--------------- All CPP and Header Files with "dragonfly.log"

README.txt
DragonFly Engine.sln

SFML - 2.5
	|
	----------------- ALL SFML FILES REQUIRED TO RUN
	
--------------------------------------------------------------

HOW TO COMPILE:

	1) Open DragonFly Engine.sln
	2) Build and Run
	3) Verify Output in 'dragonfly.log' in DragonFly Engine Folder

---------------------------------------------------------------

