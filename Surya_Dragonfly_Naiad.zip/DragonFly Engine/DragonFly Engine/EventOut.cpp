#include "EventOut.h"


namespace df {

	EventOut::EventOut() {
		setType(OUT_EVENT);
	}
}