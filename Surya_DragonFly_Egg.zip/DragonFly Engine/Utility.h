#pragma once


namespace df {

	class Utility
	{

	public:
		static char* getTimeString();
	};
}


