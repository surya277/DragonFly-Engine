#pragma once


namespace df {

	class Utility
	{

	public:
		char* getTimeString();
	};
}


